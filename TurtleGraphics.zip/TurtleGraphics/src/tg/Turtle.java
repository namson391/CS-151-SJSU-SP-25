package tg;

import java.util.List;
import tools.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Turtle extends Publisher implements Serializable {
    public static int WORLD_SIZE = 250;
    private List<RestPoint> path;

    public Turtle() {
        path = new ArrayList<RestPoint>();
        RestPoint location = new RestPoint(WORLD_SIZE / 2, WORLD_SIZE / 2, Color.RED, false);
        path.add(location);
    }

    public RestPoint getLocation() {
        RestPoint result = null;
        if (path.isEmpty()) {
            // probably should throw an exception here but then
            // paintComponent must catch it and do what?
            result = new RestPoint(0, 0, Color.BLACK,true);
        } else {
            result = path.get(path.size() - 1);
        }
        return result;
    }

    public void move(Heading heading, Integer steps) throws Exception {
        RestPoint dest = null; // destination
        RestPoint location = getLocation();
        switch (heading) {
            case WEST: {
                dest = new RestPoint((Math.max(0, location.getXc() - steps)), location.getYc(), location.getColor(), location.isPenUp());
                break;
            }
            case EAST: {
                dest = new RestPoint(Math.min(WORLD_SIZE, location.getXc() + steps), location.getYc(), location.getColor(), location.isPenUp());
                break;
            }
            case SOUTH: {
                dest = new RestPoint(location.getXc(), Math.min(WORLD_SIZE, location.getYc() + steps), location.getColor(), location.isPenUp());
                break;
            }
            case NORTH: {
                dest = new RestPoint(location.getXc(), Math.max(0, location.getYc() - steps)  % WORLD_SIZE, location.getColor(), location.isPenUp());
                break;
            }
            default: {
                throw new Exception("Invalid command in Turtle.move");
            }
        }
        path.add(dest);
        notifySubscribers();
    }

    public void clear() {
        path.clear();
        RestPoint location = new RestPoint(WORLD_SIZE / 2, WORLD_SIZE / 2, Color.RED, false);
        path.add(location); // start over
        notifySubscribers();
    }

    public void setPenUp(boolean penUp) {
        this.getLocation().setPenUp(penUp);
        notifySubscribers();
    }

    public boolean isPenUp() {
        return getLocation().isPenUp();
    }

    public void setColor(Color newColor) {
        getLocation().setColor(newColor);
    }

    public Color getColor() {
        return getLocation().getColor();
    }

    public Iterator<RestPoint> iterator() {
        return path.iterator();
    }
}
