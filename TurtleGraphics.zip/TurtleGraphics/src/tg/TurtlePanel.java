package tg;

import tools.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TurtlePanel extends JPanel implements ActionListener {

    private Turtle turtle;
    private TurtleView view;

    public TurtlePanel() {
        turtle = new Turtle();
        view = new TurtleView(turtle);
        view.setBackground((Color.WHITE));
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground((Color.cyan));

        JButton north, south, east, west, clear, pen, color;

        JPanel p = new JPanel();
        p.setOpaque(false);
        north = new JButton("NORTH");
        north.addActionListener(this);
        p.add(north);
        controlPanel.add(p);

        p = new JPanel();
        p.setOpaque(false);
        east = new JButton("EAST");
        east.addActionListener(this);
        p.add(east);
        controlPanel.add(p);

        p = new JPanel();
        p.setOpaque(false);
        west = new JButton("WEST");
        west.addActionListener(this);
        p.add(west);
        controlPanel.add(p);

        p = new JPanel();
        p.setOpaque(false);
        south = new JButton("SOUTH");
        south.addActionListener(this);
        p.add(south);
        controlPanel.add(p);

        p = new JPanel();
        p.setOpaque(false);
        clear = new JButton("Clear");
        clear.addActionListener(this);
        p.add(clear);
        controlPanel.add(p);

        p = new JPanel();
        p.setOpaque(false);
        pen = new JButton("Pen");
        pen.addActionListener(this);
        p.add(pen);
        controlPanel.add(p);

        p = new JPanel();
        p.setOpaque(false);
        color = new JButton("Color");
        color.addActionListener(this);
        p.add(color);
        controlPanel.add(p);

        JFrame frame = new JFrame();
        Container cp = frame.getContentPane();
        cp.add(this);
        frame.setJMenuBar(this.createMenuBar());
        frame.setDefaultCloseOperation(3);
        frame.setTitle("Turtle Graphics");
        frame.setSize(500, 300);

        this.setLayout((new GridLayout(1, 2)));
        this.add(controlPanel);
        this.add(view);

        frame.setVisible(true);
    }

    protected JMenuBar createMenuBar() {
        JMenuBar result = new JMenuBar();
        JMenu fileMenu = Utilities.makeMenu("File", new String[]{"New", "Save", "Open", "Quit"}, this);
        result.add(fileMenu);
        JMenu editMenu = Utilities.makeMenu("Edit", new String[]{"NORTH", "SOUTH", "EAST", "WEST", "Clear", "Pen", "Color"}, this);
        result.add(editMenu);
        JMenu helpMenu = Utilities.makeMenu("Help", new String[]{"About", "Help"}, this);
        result.add(helpMenu);
        return result;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            String cmmd = e.getActionCommand();
            // using the new switch command:
            switch(cmmd) {
                case "NORTH", "EAST", "SOUTH", "WEST" -> {
                    int steps = Integer.parseInt(Utilities.ask("How many steps?"));
                    turtle.move(Heading.parse(cmmd), steps);
                }
                case "Clear" -> turtle.clear();
                case "Pen" -> turtle.setPenUp(!turtle.isPenUp());
                case "Color" -> {
                    Color newColor = JColorChooser.showDialog(null, "Pick a color", turtle.getColor());
                    turtle.setColor(newColor);
                }
                case "Save" -> {
                    String fName = Utilities.getFileName((String) null, false);
                    ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(fName));
                    os.writeObject(this.turtle);
                    os.close();
                }
                case "Open" -> {
                    String fName = Utilities.getFileName((String) null, true);
                    ObjectInputStream is = new ObjectInputStream(new FileInputStream(fName));
                    this.turtle = (Turtle) is.readObject();
                    this.view.setTurtle(turtle);
                    is.close();
                }
                case "New" -> {
                    turtle = new Turtle();
                    view.setTurtle(turtle);
                }
                case "Quit" -> System.exit(0); // normal exit
                case "About" -> Utilities.inform("Cyberdellic Designs Turtle Graphics, 2021. All rights reserved.");
                case "Help" -> Utilities.inform(
                        new String[] {
                                "North, South, East, West prompts user for number of steps, then moves turtle in the specified heading",
                                "Clear erases the turtle's path and resets its location",
                                "Pen toggles the turtle's pen up and down",
                                "Color changes the color of the turtle's pen"}
                );
                default -> throw new Exception("Unrecognized command: " + cmmd);
            }
        } catch (Exception gripe) {
            Utilities.error(gripe);
        }
    }

    public static void main(String[] args) {
        TurtlePanel app = new TurtlePanel();
    }
}



