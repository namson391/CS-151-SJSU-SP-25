package tg;

import tools.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TurtleView extends JPanel implements Subscriber {

    private Turtle turtle;

    public TurtleView(Turtle turtle) {
        this.turtle = turtle;
        turtle.subscribe(this);
        setSize(Turtle.WORLD_SIZE, Turtle.WORLD_SIZE);
        Border blackline = BorderFactory.createLineBorder(Color.black);
        setBorder(blackline);
    }

    // called from file/open and file/new
    public void setTurtle(Turtle newTurtle) {
        turtle.unsubscribe(this);
        turtle = newTurtle;
        turtle.subscribe(this);
        repaint();
    }

    public void update() { repaint(); }

    public void paintComponent(Graphics gc) {
        super.paintComponent(gc);
        Color oldColor = gc.getColor();
        Iterator<RestPoint> it = turtle.iterator();
        if (it.hasNext()) {
            RestPoint p1 = it.next();
            while(it.hasNext()) {
                RestPoint p2 = it.next();
                if (!p1.isPenUp()) {
                    gc.setColor(p1.getColor());
                    gc.drawLine(p1.getXc(), p1.getYc(), p2.getXc(), p2.getYc());
                }
                p1 = p2;
            }
        }
        // draw the turtle
        gc.setColor(Color.GREEN);
        RestPoint location = turtle.getLocation();
        if (location.isPenUp()) {
            gc.drawOval(location.getXc(),location.getYc() , 10, 10);
        } else {
            gc.fillOval(location.getXc(),location.getYc(), 10, 10);
        }

        gc.setColor(oldColor);
    }
}
