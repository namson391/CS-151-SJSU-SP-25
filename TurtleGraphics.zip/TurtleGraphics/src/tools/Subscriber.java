package tools;

public interface Subscriber {
    void update();
}