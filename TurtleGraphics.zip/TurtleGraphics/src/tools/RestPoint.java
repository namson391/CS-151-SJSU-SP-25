package tools;

import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class RestPoint implements Serializable {
    private int xc, yc;
    private Color color;
    private boolean penUp;

    public RestPoint(int xc, int yc, Color color, boolean penUp) {
        this.xc = xc;
        this.yc = yc;
        this.color = color;
        this.penUp = penUp;
    }

    public RestPoint() {
        this(0, 0, Color.BLACK, false);
    }

    public int getXc() {
        return xc;
    }

    public int getYc() {
        return yc;
    }

    public Color getColor() {
        return color;
    }

    public boolean isPenUp() {
        return penUp;
    }

    public void setPenUp(boolean penUp) {
        this.penUp = penUp;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}
