package tools;

public enum Heading {
    WEST, EAST, SOUTH, NORTH;
    public static Heading parse(String h) {
        if (h.equalsIgnoreCase("WEST")) return WEST;
        if (h.equalsIgnoreCase("EAST")) return EAST;
        if (h.equalsIgnoreCase("SOUTH")) return SOUTH;
        if (h.equalsIgnoreCase("NORTH")) return NORTH;
        return NORTH;
    }
}